﻿To start this project first you mast call the following, or the MSMQ will not work!!
Note that at each start the logs are cleaned

{ECQRSFramrework.sln directory}\Utils\StartMassTransitMSMQ.bat