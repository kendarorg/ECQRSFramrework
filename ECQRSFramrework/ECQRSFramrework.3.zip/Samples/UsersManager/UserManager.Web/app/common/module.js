var common = angular.module('commonModule',['ngRoute','sgDialogService']);

